function playSound(){
    var beep = new Audio();
    beep.src = "myaudio.mp3";
    beep.play();
}